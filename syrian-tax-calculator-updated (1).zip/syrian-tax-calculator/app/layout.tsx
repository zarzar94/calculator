import type React from "react"
import type { Metadata } from "next"
import { Tajawal } from "next/font/google"
import "./globals.css"

const tajawal = Tajawal({
  subsets: ["arabic"],
  weight: ["300", "400", "500", "700", "900"],
  display: "swap",
  variable: "--font-tajawal",
})

export const metadata: Metadata = {
  title: "حاسبة الضرائب الإلكترونية السورية - وزارة المالية",
  description:
    "تمكن هذه الأداة المواطنين من احتساب الضرائب المستحقة بدقة وسهولة، وفقاً لنوع الضريبة، بما يعزز الشفافية ويبسّط الإجراءات.",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl" className={`${tajawal.variable} antialiased`}>
      <body className="font-sans">{children}</body>
    </html>
  )
}

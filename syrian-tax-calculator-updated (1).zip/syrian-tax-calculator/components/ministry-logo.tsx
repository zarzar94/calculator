interface MinistryLogoProps {
  width?: number
  height?: number
  className?: string
}

export function MinistryLogo({ width = 200, height = 40, className = "" }: MinistryLogoProps) {
  return (
    <img
      src="/images/ministry-logo.png"
      alt="Ministry of Finance - وزارة المالية"
      width={width}
      height={height}
      className={className}
    />
  )
}

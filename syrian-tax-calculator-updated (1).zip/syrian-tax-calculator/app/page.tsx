"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Building2,
  Key,
  TrendingUp,
  DollarSign,
  CreditCard,
  FileText,
  Table,
} from "lucide-react"

// Extend the tax types to include all calculators from the legacy HTML version.
type TaxType =
  | "property"
  | "rent"
  | "profit"
  | "lump"
  | "salary"
  | "stamp"
  | "profitCompare"

interface TaxResult {
  items: Array<{ label: string; value: number }>
  /**
   * The total field is used for the final summary row.  For most
   * calculators it represents the sum of the item values (e.g. total
   * tax due).  For the profit comparison calculator this field is
   * re‑purposed to hold the minimum tax value among all scenarios.  The
   * label of the summary row is adjusted based on the selected tax
   * type when rendering.  Using a unified structure simplifies the
   * rendering logic without sacrificing clarity.
   */
  total: number
}

export default function SyrianTaxCalculator() {
  const [selectedTax, setSelectedTax] = useState<TaxType | null>(null)
  const [result, setResult] = useState<TaxResult | null>(null)

  // Additional state to drive dynamic fields in the stamp calculator.  The
  // selected stamp category determines which inputs to show (capital and
  // public offer).  See STAMP_CATEGORIES for details on category types.
  const [stampCategory, setStampCategory] = useState<string>("general")

  const fmt = (n: number) => n.toLocaleString("ar-SY")

  const taxTypes = [
    {
      id: "property" as TaxType,
      title: "ضرائب عقارية",
      description: "ضرائب بيع العقار (قانون 15/2021)",
      icon: Building2,
    },
    {
      id: "rent" as TaxType,
      title: "ضريبة الإيجار العقارية",
      description: "حساب الضريبة على الإيجارات العقارية",
      icon: Key,
    },
    {
      id: "profit" as TaxType,
      title: "ضريبة الأرباح الحقيقية",
      description: "ضريبة على الأرباح للشركات والأفراد",
      icon: TrendingUp,
    },
    {
      id: "lump" as TaxType,
      title: "الدخل المقطوع",
      description: "تقدير الضريبة على المقطوع",
      icon: DollarSign,
    },
    {
      id: "salary" as TaxType,
      title: "ضريبة الرواتب والأجور",
      description: "حساب ضريبة الرواتب والأجور",
      icon: CreditCard,
    },
    {
      id: "stamp" as TaxType,
      title: "رسوم الطابع",
      description: "حساب رسوم الطابع للوثائق",
      icon: FileText,
    },
    {
      id: "profitCompare" as TaxType,
      title: "مقارنة الأرباح (24/51/30)",
      description: "مقارنة الأنظمة الضريبية المختلفة",
      icon: Table,
    },
  ]

  const calculateProperty = (formData: FormData) => {
    const value = Number(formData.get("propValue")) || 0
    const type = formData.get("propType") as string
    const isGift = formData.get("propGift") === "on"

    if (value <= 0) {
      alert("يرجى إدخال قيمة صحيحة")
      return
    }

    const rates: Record<string, number> = {
      residential: 0.01,
      commercial: 0.03,
      landInside: 0.02,
      landOutside: 0.01,
      roof: 0.01,
    }

    let base = value * (rates[type] || 0.01)
    if (isGift) base *= 0.15

    const local = base * 0.1
    const recon = base * 0.1
    const total = base + local + recon

    setResult({
      items: [
        { label: "الضريبة الأساسية", value: base },
        { label: "إدارة محلية", value: local },
        { label: "إعمار", value: recon },
      ],
      total,
    })
  }

  const calculateRent = (formData: FormData) => {
    const rent = Number(formData.get("rentValue")) || 0
    const propValue = Number(formData.get("rentPropValue")) || 0
    const type = formData.get("rentType") as string
    const furnished = formData.get("rentFurnished") === "on"

    if (rent <= 0 || propValue <= 0) {
      alert("يرجى إدخال القيم بشكل صحيح")
      return
    }

    const rate = type === "residential" ? 0.05 : 0.1
    const minFactor = type === "residential" ? 0.0003 : 0.0006
    const valueForMin = type === "residential" && furnished ? propValue * 1.25 : propValue

    const fromRent = rent * rate
    const minimum = valueForMin * minFactor
    const due = Math.max(fromRent, minimum)

    setResult({
      items: [
        { label: "من البدل", value: fromRent },
        { label: "الحد الأدنى", value: minimum },
      ],
      total: due,
    })
  }

  const BRACKETS = [
    { limit: 3_000_000, rate: 0.0 },
    { limit: 10_000_000, rate: 0.1 },
    { limit: 30_000_000, rate: 0.14 },
    { limit: 100_000_000, rate: 0.18 },
    { limit: 500_000_000, rate: 0.22 },
    { limit: Number.POSITIVE_INFINITY, rate: 0.25 },
  ]

  const calculateIndividualTax = (amount: number) => {
    let remaining = amount
    let prevLimit = 0
    let total = 0

    for (const bracket of BRACKETS) {
      const cap = Math.min(remaining, bracket.limit - prevLimit)
      if (cap <= 0) break
      total += cap * bracket.rate
      remaining -= cap
      prevLimit = bracket.limit
    }
    return total
  }

  const calculateProfit = (formData: FormData) => {
    const profit = Number(formData.get("profitValue")) || 0
    const type = formData.get("profitType") as string

    if (profit <= 0) {
      alert("يرجى إدخال ربح صحيح")
      return
    }

    let base: number
    if (type === "individual") {
      base = calculateIndividualTax(profit)
    } else {
      const corpType = formData.get("corpType") as string
      const rates: Record<string, number> = {
        jscPublic: 0.15,
        companyOther: 0.2,
        bankInsurance: 0.25,
        oilGas: 0.35,
      }
      base = profit * (rates[corpType] || 0.2)
    }

    const local = base * 0.1
    const recon = base * 0.1
    const total = base + local + recon

    setResult({
      items: [
        { label: "الأساسية", value: base },
        { label: "إدارة محلية", value: local },
        { label: "إعمار", value: recon },
      ],
      total,
    })
  }

  /**
   * حساب ضريبة الدخل المقطوع.  يستند إلى التعليمات الواردة في
   * الإصدار السابق بحيث يُحسب الربح التقديري من رقم العمل وهامش
   * الربح، ثم يخضع الجزء الزائد عن مليار ليرة لنسب 3٪ تصنيف، و10٪
   * إدارة محلية، و10٪ أجور، و10٪ إعمار.  المجموع يمثل 33٪ من
   * الجزء الخاضع.
   */
  const calculateLump = (formData: FormData) => {
    const t = Number(formData.get("lumpTurnover")) || 0
    const m = Number(formData.get("lumpMargin")) || 0
    if (t < 0 || m < 0) {
      alert("تحقق من المدخلات")
      return
    }
    const profitEst = Math.max(0, t * (m / 100))
    const lumpsumBase = Math.max(0, profitEst - 1_000_000_000)
    const classification = lumpsumBase * 0.03
    const loc = lumpsumBase * 0.10
    const wages = lumpsumBase * 0.10
    const rec = lumpsumBase * 0.10
    const total = classification + loc + wages + rec
    setResult({
      items: [
        { label: "تصنيف (3%)", value: classification },
        { label: "إدارة محلية (10%)", value: loc },
        { label: "أجور (10%)", value: wages },
        { label: "إعمار (10%)", value: rec },
      ],
      total,
    })
  }

  /**
   * حساب ضريبة الرواتب والأجور.  يدعم خيار الضريبة المقطوعة 5٪ أو
   * الشرائح التصاعدية حسب الفترة المختارة.  إذا كان الراتب خاضعاً
   * للتأمينات الاجتماعية يتم خصم 7٪ قبل الحساب.
   */
  const calculateSalary = (formData: FormData) => {
    const income = Number(formData.get("salaryValue")) || 0
    if (income <= 0) {
      alert("أدخل راتباً صحيحاً")
      return
    }
    const period = formData.get("salaryDate") as string
    const lumpOpt = formData.get("salaryLumpOption") === "on"
    const insurance = formData.get("salaryInsurance") as string
    let taxableIncome = income
    if (insurance === "insured") {
      taxableIncome = income * 0.93
    }
    // Flat 5% option
    if (lumpOpt) {
      const total = taxableIncome * 0.05
      setResult({
        items: [
          { label: "الراتب الخاضع", value: taxableIncome },
          { label: "ضريبة 5%", value: total },
        ],
        total,
      })
      return
    }
    // Progressive brackets
    type Bracket = { limit: number; rate: number }
    const salaryBrackets_2023_09: Bracket[] = [
      { limit: 250_000, rate: 0.05 },
      { limit: 450_000, rate: 0.07 },
      { limit: 650_000, rate: 0.09 },
      { limit: 850_000, rate: 0.11 },
      { limit: 1_100_000, rate: 0.13 },
      { limit: Number.POSITIVE_INFINITY, rate: 0.15 },
    ]
    const salaryBrackets_2024_03: Bracket[] = [
      { limit: 450_000, rate: 0.07 },
      { limit: 650_000, rate: 0.09 },
      { limit: 850_000, rate: 0.11 },
      { limit: 1_100_000, rate: 0.13 },
      { limit: Number.POSITIVE_INFINITY, rate: 0.15 },
    ]
    const brackets = period === "2023-09" ? salaryBrackets_2023_09 : salaryBrackets_2024_03
    let remaining = taxableIncome
    let prev = 0
    let totalTax = 0
    const details: Array<{ label: string; value: number }> = []
    for (const [index, b] of brackets.entries()) {
      const cap = Math.min(remaining, b.limit - prev)
      if (cap <= 0) break
      const tax = cap * b.rate
      totalTax += tax
      details.push({
        label: `شريحة ${index + 1}: ${fmt(cap)} ل.س × ${(b.rate * 100).toFixed(0)}%`,
        value: tax,
      })
      remaining -= cap
      prev = b.limit
    }
    setResult({ items: details, total: totalTax })
  }

  /**
   * تصنيف رسوم الطابع حسب الفئة ونوع الوثيقة.  يتعامل مع الأنواع
   * النسبية والثابتة والمختلطة، مع إمكانية احتساب نسخة أو أكثر.  إذا
   * كانت الفئة مساهمة عامة يستخدم معدل خاص عند طرح الأسهم.
   */
  const STAMP_CATEGORIES = {
    general: { type: "percentage", rate: 0.004, label: "عقد بمبلغ محدد" },
    guarantee: { type: "percentage", rate: 0.003, label: "كفالة مالية" },
    insurance: { type: "fixed", amount: 5000, label: "وثائق تأمين" },
    partnership: { type: "mixed", baseFee: 25000, rate: 0.005, label: "شركة أشخاص" },
    jointStock: { type: "mixed", rate: 0.005, publicRate: 0.0025, label: "شركة مساهمة" },
    llc: { type: "mixed", baseFee: 25000, rate: 0.005, label: "محدودة المسؤولية" },
    documentNoAmount: { type: "fixed", amount: 5000, label: "وثيقة بلا مبلغ" },
  } as const

  const calculateStamp = (formData: FormData) => {
    const catKey = (formData.get("stampCategory") as string) || "general"
    const cat = STAMP_CATEGORIES[catKey as keyof typeof STAMP_CATEGORIES]
    const value = Number(formData.get("stampValue")) || 0
    const capital = Number(formData.get("stampCapital")) || 0
    const copies = Number(formData.get("stampCopies")) || 1
    const publicOffer = formData.get("stampPublicOffer") === "on"
    let base = 0
    if (cat) {
      if (cat.type === "percentage") base = value * (cat.rate ?? 0)
      else if (cat.type === "fixed") base = cat.amount ?? 0
      else if (cat.type === "mixed") {
        const rate = publicOffer && cat.publicRate ? cat.publicRate : cat.rate ?? 0
        base = (cat.baseFee ?? 0) + capital * rate
      }
    }
    const nat = base * 0.10
    const loc = base * 0.05
    const perOne = base + nat + loc
    const total = perOne * copies
    const items: Array<{ label: string; value: number }> = []
    items.push({ label: "الرسوم الأساسية", value: base })
    items.push({ label: "المساهمة الوطنية (10%)", value: nat })
    items.push({ label: "إدارة محلية (5%)", value: loc })
    items.push({ label: "الإجمالي للنسخة الواحدة", value: perOne })
    if (copies > 1) {
      items.push({ label: "الإجمالي لجميع النسخ", value: total })
    }
    setResult({ items, total })
  }

  /**
   * مقارنة قيمة الضريبة بين قانون 24 ومرسوم 51 ومرسوم 30 بأنواع
   * الشركات المختلفة.  يحسب لكل سيناريو القيمة المستحقة ويحدد
   * الحد الأدنى.  يتم تخزين هذا الحد الأدنى فى حقل total لتسهيل
   * عرض النتيجة فى الصف الختامى.
   */
  const calculateCompare = (formData: FormData) => {
    const p = Number(formData.get("compareProfit")) || 0
    if (p <= 0) {
      alert("أدخل ربحاً صحيحاً")
      return
    }
    // Law 24 uses the individual tax brackets defined earlier (same as
    // calculateIndividualTax).  Decree 51 is a flat 28% and Decree 30
    // varies by corporate type.
    const law24 = calculateIndividualTax(p)
    const dec51 = p * 0.28
    const jsc = p * 0.15
    const other = p * 0.20
    const bank = p * 0.25
    const oil = p * 0.35
    const values = [law24, dec51, jsc, other, bank, oil]
    const minVal = Math.min(...values)
    const items = [
      { label: "قانون 24", value: law24 },
      { label: "مرسوم 51", value: dec51 },
      { label: "مرسوم 30 – مساهمة عامة", value: jsc },
      { label: "مرسوم 30 – باقي الشركات", value: other },
      { label: "مرسوم 30 – مصارف/تأمين", value: bank },
      { label: "مرسوم 30 – نفط وغاز", value: oil },
    ]
    setResult({ items, total: minVal })
  }

  const renderTaxForm = () => {
    if (!selectedTax) return null

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault()
      const formData = new FormData(e.currentTarget)

      switch (selectedTax) {
        case "property":
          calculateProperty(formData)
          break
        case "rent":
          calculateRent(formData)
          break
        case "profit":
          calculateProfit(formData)
          break
          case "lump":
            calculateLump(formData)
            break
          case "salary":
            calculateSalary(formData)
            break
          case "stamp":
            calculateStamp(formData)
            break
          case "profitCompare":
            calculateCompare(formData)
            break
        // Add other cases as needed
      }
    }

    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="text-right">{taxTypes.find((t) => t.id === selectedTax)?.title}</CardTitle>
          <CardDescription className="text-right">
            {taxTypes.find((t) => t.id === selectedTax)?.description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {selectedTax === "property" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="propValue" className="text-right block">
                    قيمة العقار (ل.س)
                  </Label>
                  <Input
                    id="propValue"
                    name="propValue"
                    type="number"
                    placeholder="أدخل قيمة العقار"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="propType" className="text-right block">
                    نوع العقار
                  </Label>
                  <Select name="propType">
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر نوع العقار" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">سكني</SelectItem>
                      <SelectItem value="commercial">غير سكني (تجاري/صناعي)</SelectItem>
                      <SelectItem value="landInside">أرض داخل المخطط</SelectItem>
                      <SelectItem value="landOutside">أرض خارج المخطط</SelectItem>
                      <SelectItem value="roof">سطح سكني</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox id="propGift" name="propGift" />
                  <Label htmlFor="propGift" className="text-right">
                    هبة للأصول/الفروع/الزوج
                  </Label>
                </div>
              </>
            )}

            {selectedTax === "rent" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="rentValue" className="text-right block">
                    إجمالي بدل الإيجار السنوي (ل.س)
                  </Label>
                  <Input
                    id="rentValue"
                    name="rentValue"
                    type="number"
                    placeholder="أدخل بدل الإيجار السنوي"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rentPropValue" className="text-right block">
                    القيمة الرائجة للعقار (ل.س)
                  </Label>
                  <Input
                    id="rentPropValue"
                    name="rentPropValue"
                    type="number"
                    placeholder="أدخل القيمة الرائجة"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rentType" className="text-right block">
                    نوع الاستخدام
                  </Label>
                  <Select name="rentType">
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر نوع الاستخدام" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">سكني</SelectItem>
                      <SelectItem value="commercial">تجاري/غير سكني</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox id="rentFurnished" name="rentFurnished" />
                  <Label htmlFor="rentFurnished" className="text-right">
                    مفروش
                  </Label>
                </div>
              </>
            )}

            {selectedTax === "profit" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="profitValue" className="text-right block">
                    صافي الربح السنوي (ل.س)
                  </Label>
                  <Input
                    id="profitValue"
                    name="profitValue"
                    type="number"
                    placeholder="أدخل صافي الربح السنوي"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="profitType" className="text-right block">
                    نوع المكلف
                  </Label>
                  <Select name="profitType">
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر نوع المكلف" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="individual">فرد/شركات أشخاص</SelectItem>
                      <SelectItem value="corporate">شركة أموال</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {selectedTax === "lump" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="lumpTurnover" className="text-right block">
                    رقم العمل السنوي (ل.س)
                  </Label>
                  <Input
                    id="lumpTurnover"
                    name="lumpTurnover"
                    type="number"
                    placeholder="أدخل رقم العمل السنوي"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lumpMargin" className="text-right block">
                    هامش الربح التقديري (%)
                  </Label>
                  <Input
                    id="lumpMargin"
                    name="lumpMargin"
                    type="number"
                    placeholder="مثال: 15"
                    min="0"
                    step="0.1"
                    className="text-right"
                  />
                </div>
              </>
            )}

            {selectedTax === "salary" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="salaryValue" className="text-right block">
                    الراتب الشهري الإجمالي (ل.س)
                  </Label>
                  <Input
                    id="salaryValue"
                    name="salaryValue"
                    type="number"
                    placeholder="أدخل الراتب الشهري"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="salaryDate" className="text-right block">
                    تاريخ الاستحقاق
                  </Label>
                  <Select name="salaryDate" defaultValue="2023-09">
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الفترة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023-09">من 1/9/2023 حتى 29/2/2024</SelectItem>
                      <SelectItem value="2024-03">من 1/3/2024 وما بعد</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="salaryInsurance" className="text-right block">
                    الاشتراك في التأمينات الاجتماعية
                  </Label>
                  <Select name="salaryInsurance" defaultValue="noninsured">
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="insured">خاضع للتأمينات</SelectItem>
                      <SelectItem value="noninsured">غير خاضع للتأمينات</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox id="salaryLumpOption" name="salaryLumpOption" />
                  <Label htmlFor="salaryLumpOption" className="text-right">
                    الضريبة المقطوعة (5%)
                  </Label>
                </div>
              </>
            )}

            {selectedTax === "stamp" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="stampCategory" className="text-right block">
                    الفئة
                  </Label>
                  <Select
                    name="stampCategory"
                    value={stampCategory}
                    onValueChange={(val) => setStampCategory(val)}
                  >
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(STAMP_CATEGORIES).map((key) => (
                        <SelectItem key={key} value={key}>
                          {STAMP_CATEGORIES[key as keyof typeof STAMP_CATEGORIES].label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="stampValue" className="text-right block">
                    قيمة الأساس (ل.س)
                  </Label>
                  <Input
                    id="stampValue"
                    name="stampValue"
                    type="number"
                    placeholder="أدخل قيمة الأساس"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
                {/* Capital input appears for mixed categories */}
                {(() => {
                  const cat = STAMP_CATEGORIES[stampCategory as keyof typeof STAMP_CATEGORIES]
                  return cat?.type === "mixed" ? (
                    <div className="space-y-2">
                      <Label htmlFor="stampCapital" className="text-right block">
                        رأس المال (ل.س)
                      </Label>
                      <Input
                        id="stampCapital"
                        name="stampCapital"
                        type="number"
                        placeholder="أدخل رأس المال"
                        min="0"
                        step="1"
                        className="text-right"
                      />
                    </div>
                  ) : null
                })()}
                {/* Public offer checkbox only for jointStock */}
                {stampCategory === "jointStock" && (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Checkbox id="stampPublicOffer" name="stampPublicOffer" />
                    <Label htmlFor="stampPublicOffer" className="text-right">
                      طرح أسهم للاكتتاب العام
                    </Label>
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor="stampCopies" className="text-right block">
                    عدد النسخ
                  </Label>
                  <Input
                    id="stampCopies"
                    name="stampCopies"
                    type="number"
                    placeholder="2"
                    min="1"
                    step="1"
                    defaultValue={2}
                    className="text-right"
                  />
                </div>
              </>
            )}

            {selectedTax === "profitCompare" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="compareProfit" className="text-right block">
                    الربح السنوي (ل.س)
                  </Label>
                  <Input
                    id="compareProfit"
                    name="compareProfit"
                    type="number"
                    placeholder="أدخل الربح السنوي"
                    min="0"
                    step="1"
                    className="text-right"
                  />
                </div>
              </>
            )}

            <div className="flex gap-4 justify-end">
              <Button type="button" variant="outline" onClick={() => setResult(null)}>
                إعادة تعيين
              </Button>
              <Button type="submit">احسب الضريبة</Button>
            </div>
          </form>

          {result && (
            (() => {
              // Determine minimum value for profit comparisons.  For other
              // calculators this remains null and no highlighting is applied.
              const minValue =
                selectedTax === "profitCompare"
                  ? Math.min(...result.items.map((it) => it.value))
                  : null
              return (
                <Card
                  className="mt-6 text-white"
                  style={{ background: `linear-gradient(135deg, #428177, #356b62)` }}
                >
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {result.items.map((item, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center py-2 border-b border-white/20"
                        >
                          <span
                            className={`${
                              selectedTax === "profitCompare" && item.value === minValue
                                ? "text-green-300"
                                : "text-yellow-200"
                            } font-semibold`}
                          >
                            {fmt(item.value)} ل.س
                          </span>
                          <span>{item.label}</span>
                        </div>
                      ))}
                      <div className="flex justify-between items-center pt-4 border-t-2 border-yellow-400 text-lg font-bold">
                        <span className="text-yellow-300">{fmt(result.total)} ل.س</span>
                        <span>{selectedTax === "profitCompare" ? "الأقل" : "الإجمالي"}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })()
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-green-50" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-yellow-600">
        <div className="max-w-7xl mx-auto px-4 py-6" style={{ backgroundColor: "#428177" }}>
          {/* Dalili header with gold gradient text and Arabic styling */}
          <div className="flex items-center justify-between">
            {/* Ministry Logo */}
            <div className="flex-shrink-0">
              <img src="/images/ministry-logo-new.svg" alt="Ministry of Finance Logo" className="h-16 w-auto" />
            </div>

            {/* Dalili Branding */}
            <div className="text-right">
              
              
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-12 bg-[rgba(235,232,215,1)]">
        {/* Page Title */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-[rgba(109,34,45,1)]" style={{ color: "#428177" }}>
            حاسبة الضرائب
          </h2>
          <p className="text-lg max-w-3xl mx-auto text-[rgba(109,34,45,1)]">
            تمكن هذه الأداة المواطنين من احتساب الضرائب المستحقة بدقة وسهولة.
          </p>
        </div>

        {/* Tax Type Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {taxTypes.map((tax) => {
            const Icon = tax.icon
            return (
              <Card
                key={tax.id}
                className={`cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${
                  selectedTax === tax.id
                    ? "text-white border-yellow-500 border-2"
                    : "bg-white hover:border-yellow-500 border-2 border-transparent"
                }`}
                style={{
                  backgroundColor: selectedTax === tax.id ? "#428177" : "white",
                }}
                onClick={() => {
                  setSelectedTax(tax.id)
                  setResult(null)
                }}
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                      selectedTax === tax.id ? "bg-yellow-500" : "bg-amber-100"
                    }`}
                    style={{
                      color: "#6d222d",
                    }}
                  >
                    <Icon size={32} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{tax.title}</h3>
                  <p className={`text-sm ${selectedTax === tax.id ? "text-white/80" : "text-gray-600"}`}>
                    {tax.description}
                  </p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {renderTaxForm()}
      </div>
    </div>
  )
}
